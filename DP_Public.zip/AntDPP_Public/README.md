# AntDPP: Target-oriented Antibody Design with Pre-training and Prior Biological Structure Knowledge

## Cite
To be added...

## overview model
![avatar](./pic/AntDPP.png)

## Envs
The code requires python 3.7+ and packages listed in the requiements.txt. To create environment to run the code, you can simply run:
> pip3 install -r requirements.txt

## Database
Download from public database, detail preprocessed is described in the paper.
[OAS Dataset](https://opig.stats.ox.ac.uk/webapps/oas/),
[SARS-CoV-2 Dataset](https://opig.stats.ox.ac.uk/webapps/covabdab/),
[RAbD Dataset](http://dunbrack2.fccc.edu/%20PyIgClassify)
## Useage
Antigen_Antibody is our critic model. AntiTranslate is include our Generation model(AntDPP).We provide 5M pre-training weights, and we can increase the antibody library by 5M weights. With the command 
> `python Staircase_generation.py`.

We will available for download 5M pre-training weights [link]().
When generating cdr1, you need to provide the corresponding antibody's frameworks, we provide examples here in the data file. If the corresponding parameter weight path is `None`, the corresponding region is not generated.